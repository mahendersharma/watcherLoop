// autoPostWatcher.js
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const fs = require('fs');

puppeteer.use(StealthPlugin());

const PROFILE_URL = 'https://truthsocial.com/@PhonatoStudio';
const LAST_POST_PATH = './latest.json';
const DEBUG_HTML = './debug.html';
const CHECK_INTERVAL_MS = 60 * 1000;

async function getLatestPost() {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox'],
  });

  const page = await browser.newPage();

  try {
    console.log('➡️ Navigating to profile...');
    await page.goto(PROFILE_URL, { waitUntil: 'networkidle2', timeout: 60000 });
    await page.waitForTimeout(5000);

    const selector = '.status__content-wrapper p';

    console.log(`🔍 Waiting for post container: ${selector}`);
    await page.waitForSelector(selector, { timeout: 45000 });

    const post = await page.evaluate((sel) => {
      const el = document.querySelector(sel);
      return el ? el.innerText.trim() : null;
    }, selector);

    await browser.close();
    return post;
  } catch (e) {
    // Timeout or selector not found
    await browser.close();
    return null; // Handle gracefully in main loop
  }
}

function readLastPost() {
  if (!fs.existsSync(LAST_POST_PATH)) return null;
  try {
    return JSON.parse(fs.readFileSync(LAST_POST_PATH, 'utf-8')).text;
  } catch {
    return null;
  }
}

function savePost(text) {
  fs.writeFileSync(LAST_POST_PATH, JSON.stringify({ text }, null, 2));
}

async function watcherLoop() {
  console.log('▶️ Starting watcher...');
  while (true) {
    const latest = await getLatestPost();
console.log("latest",latest)
    if (latest) {
      const last = readLastPost();
      console.log("readLastPost",readLastPost())

      if (latest !== last) {
        console.log('\n🟢 NEW POST DETECTED:\n', latest);
        savePost(latest);
      } else {
        console.log('⏳ No new post yet...');
      }
    } else {
      console.log('⏳ No new post yet...');
    }

    await new Promise(r => setTimeout(r, CHECK_INTERVAL_MS));
  }
}

watcherLoop();
