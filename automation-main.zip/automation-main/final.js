
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const fs = require('fs');

puppeteer.use(StealthPlugin());

const PROFILE_URL = 'https://truthsocial.com/@PhonatoStudio';
const LAST_POST_PATH = './latest.json';
const CHECK_INTERVAL_MS = 60 * 1000;
const DEBUG_HTML = './debug.html';
const DEBUG_PNG = './debug.png';

async function getLatestPost() {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  const page = await browser.newPage();

  try {
    console.log('➡️ Navigating to profile...');
    await page.goto(PROFILE_URL, { waitUntil: 'networkidle2', timeout: 60000 });

    const postWrapperSelector = '.status__content-wrapper';
    await page.waitForSelector(postWrapperSelector, { timeout: 45000 });

    const result = await page.evaluate(() => {
      const wrapper = document.querySelector('.status__content-wrapper');
      if (!wrapper) return null;

      const text = Array.from(wrapper.querySelectorAll('p'))
        .map(p => p.innerText.trim())
        .filter(Boolean)
        .filter((line, index, self) => self.indexOf(line) === index) // ✅ remove duplicate lines
        .join('\n');

      const article = wrapper.closest('article');
      const postId = article?.getAttribute('data-id') || null;

      return {
        text,
        postId,
        postUrl: postId ? `https://truthsocial.com/@PhonatoStudio/post/${postId}` : null,
      };
    });

    await browser.close();

    if (!result || !result.text) {
      console.log('⚠️ No valid post content found.');
      return null;
    }

    return result;
  } catch (err) {
    console.error('❌ Error fetching post:', err.message);
    fs.writeFileSync(DEBUG_HTML, await page.content());
    await page.screenshot({ path: DEBUG_PNG });
    await browser.close();
    return null;
  }
}

function readLastPost() {
  if (!fs.existsSync(LAST_POST_PATH)) return null;
  try {
    return JSON.parse(fs.readFileSync(LAST_POST_PATH, 'utf-8'));
  } catch {
    return null;
  }
}

function savePost(data) {
  fs.writeFileSync(LAST_POST_PATH, JSON.stringify(data, null, 2));
}

function normalize(str) {
  return str.replace(/\s+/g, ' ').trim().toLowerCase();
}

async function watcherLoop() {
  console.log('▶️ Starting watcher...');
  while (true) {
    const latest = await getLatestPost();

    if (latest) {
      const lastPost = readLastPost();

      const isNewPost =
        !lastPost ||
        latest.postId !== lastPost.postId ||
        normalize(latest.text) !== normalize(lastPost.text);

      if (isNewPost) {
        console.log('\n🟢 NEW POST DETECTED:\n', latest.text);
        if (latest.postUrl) console.log('🔗 URL:', latest.postUrl);
        savePost(latest);
      } else {
        console.log('⏳ No new post yet...');
      }
    } else {
      console.log('⚠️ Could not fetch any post. Check debug.html or debug.png');
    }

    await new Promise((r) => setTimeout(r, CHECK_INTERVAL_MS));
  }
}

watcherLoop();
